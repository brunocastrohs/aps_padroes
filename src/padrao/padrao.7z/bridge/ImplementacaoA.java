package padrao.estrutural.bridge.ex1;

public class ImplementacaoA implements Implementador{
    public void operacaoConcreta() {
        System.out.println("Esta é a implementacion A ;");
    }
}
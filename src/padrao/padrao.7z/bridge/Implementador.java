package padrao.estrutural.bridge.ex1;

public interface Implementador {
    public abstract void operacaoConcreta();
}
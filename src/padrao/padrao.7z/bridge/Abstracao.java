package padrao.estrutural.bridge.ex1;

public interface Abstracao {
    public void operacao();
}
package padrao.estrutural.bridge.ex1;

public class ImplementacaoB implements Implementador{
    public void operacaoConcreta() {
        System.out.println("Esta é uma implementacion de B");
    }
}
package padrao.criacional.factorymethod.ex.b;

public abstract class Pessoa {

	public String nome;
	public String sexo;
	
}

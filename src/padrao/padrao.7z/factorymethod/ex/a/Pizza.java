package padrao.criacional.factorymethod.ex.a;

public abstract class Pizza {
	
	private float valor = 0.0f;
	
	public Pizza(float valor){
		this.valor = valor;
	}

	public float getValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}

}

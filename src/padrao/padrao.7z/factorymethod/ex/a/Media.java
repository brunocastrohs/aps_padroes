package padrao.criacional.factorymethod.ex.a;

public class Media extends Pizza{
	
	public Media(float preco){
		super(preco);
	}

}

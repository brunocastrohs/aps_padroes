package padrao.criacional.factorymethod.ex.a;

public interface PizzaConstants {
	static final float PRECO_G = 31.90f; 
	static final float PRECO_M = 25.90f; 
	static final float PRECO_P = 21.90f; 
}

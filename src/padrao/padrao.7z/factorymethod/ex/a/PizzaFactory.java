package padrao.criacional.factorymethod.ex.a;

public abstract class PizzaFactory {
	
	public static Pizza madePizza(char size){
		
		if(size == 'G')
			return new Grande(PizzaConstants.PRECO_G);
		else if(size == 'M')
			return new Media(PizzaConstants.PRECO_M);
		else if(size == 'P')
			return new Pequena(PizzaConstants.PRECO_P);
		else 
			return null;
		
	}

}

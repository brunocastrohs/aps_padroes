package padrao.criacional.factorymethod.ex.a;

public class Grande extends Pizza{
	
	public Grande(float preco){
		super(preco);
	}

}

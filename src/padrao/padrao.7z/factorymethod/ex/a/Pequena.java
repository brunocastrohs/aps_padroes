package padrao.criacional.factorymethod.ex.a;

public class Pequena extends Pizza{
	
	public Pequena(float preco){
		super(preco);
	}

}

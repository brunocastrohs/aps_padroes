package padrao.criacional.builder.ex.b;

public class Funcionario {

	String nome;
	float salario;
	int matricula;
	String cpf;
	String sobreNome;
	char genero;
	
	public Funcionario(FuncionarioBuilder fc) {
		this.nome = fc.nome;
		this.salario = fc.salario;
		this.matricula = fc.matricula;
		this.cpf = fc.cpf;
		this.sobreNome = fc.sobreNome;
		this.genero = fc.genero;
	}

	public static class FuncionarioBuilder{
		
		String nome;
		String cpf;
		float salario;
		int matricula;
		String sobreNome;
		char genero;
		
		public FuncionarioBuilder(String nome, String cpf) {
			this.nome = nome;
			this.cpf = cpf;
		}
		
		public FuncionarioBuilder salario(float salario) {
			this.salario = salario;
			return this;
		}
		
		public FuncionarioBuilder matricula(int matricula) {
			this.matricula = matricula;
			return this;
		}
		
		public FuncionarioBuilder sobreNome(String sobreNome) {
			this.sobreNome = sobreNome;
			return this;
		}
		
		public FuncionarioBuilder genero(char genero) {
			this.genero = genero;
			return this;
		}
		
		public Funcionario build() {
			return new Funcionario(this);
		}
		
	}
	
}

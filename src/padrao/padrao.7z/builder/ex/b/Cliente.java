package padrao.criacional.builder.ex.b;

public class Cliente {
	
	public static void main(String args[]){

		Funcionario fc2 = 
				new Funcionario.FuncionarioBuilder("Teste", "00000-00").salario(1000).sobreNome("de Aula").build();
				
		
		Usuario usr =  new Usuario.UsuarioBuilder("Salt4Hookies", "1113336550").dataNascimento("01/09/1979")
		        .endereco("Fifty Street, 1000").bairro("Salt District")
		        .cidade("Salt City")
		        .estado("Saltland")
		        .informacoes("Watch the salt.")
		        .build();
		
		Usuario usr2 =  new Usuario.UsuarioBuilder("Red Hat", "11133344409")
		        .dataNascimento("01/09/1979")
		        .endereco("Linus Street, 1000")
		        .bairro("Torvalds District")
		        .cidade("Linux")
		        .estado("Freeland")
		        .informacoes("Wath the I.T market way of business.")
		        .build();
		
		System.out.println("The End.");
		
	}
	
}
